# Missing Evidence Report
- RID: <RID>
- Goal: <verbatim>

## Gaps
- Axioms missing: <list>
- Citations missing: <list>
- Steps without supporting evidence: <list>

## Required to pass gates
- proof_min: <v> (coverage now <x>)
- citation_min: <v> (coverage now <y>)
