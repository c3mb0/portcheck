# Metrics Protocol (Calibration + Counterfactuals)

- `CALIBRATION.json`: thresholds + reliability curves used by planning.
- `OUTCOMES.jsonl`: one JSON per line, append-only, actual decision results.
- `COUNTERFACT_SUMMARY.json`: optional aggregated deltas vs baseline.
- `CALIBRATION_DIFF.json`: written by synchronization when thresholds improve.
