# IO Validator (Simple-LLM Hardening)
Contract:
- Writes allowed ONLY under `.context/` (pack writes elsewhere must be review-only).
- Root coordinator writes ONLY `.context/runs/<RID>/next/TOKEN.txt`.
- All JSON artifacts must parse with a strict JSON parser, sorted keys.

Acceptance:
- If a write fails validation: retry ONCE with corrected JSON; then schedule `synchronization` → `planning` and STOP.

Allowed tokens for next/TOKEN.txt (this pack family: ensemble):
['planning', 'implementation', 'code_review', 'diagnosis', 'fix', 'fix_review', 'synchronization', 'redirector']
