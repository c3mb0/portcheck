# Runtime Hints (Simple LLM)
- temperature ≤ 0.2
- top_p ≤ 0.2
- max_output_tokens: small; avoid long prose
- refuse to proceed after validation failures; degrade deterministically
