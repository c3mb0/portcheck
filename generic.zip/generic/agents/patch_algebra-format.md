---
name: patch-algebra-format
description: |
  Reference: patch signatures and non-commutativity index.
model: sonet
color: yellow
---
# Reference — Patch Algebra

## `.context/shared/patch_algebra/SIGNATURES.jsonl`
One JSON per line (sorted keys):
```
{"cell":"<cell_id>","rid":"<RID>","writes":["src/x.ts"],"reads":["src/y.ts"],"symbols":["pkg.A.fn"],"kind":"feature"}
```

## `.context/shared/patch_algebra/NONCOMMUTE.jsonl`
Pairs detected deterministically:
```
{"a":{"rid":"...","cell":"..."},"b":{"rid":"...","cell":"..."},"reason":"write_write_overlap|read_write_flow|symbol_conflict"}
```



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.

