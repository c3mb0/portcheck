---
name: pnf-format
description: |
  Plan-Normal-Form for cells; canonical AST-edit intent.
model: sonet
color: cyan
---
# Plan-Normal-Form (PNF)

## Location
- `.context/runs/<RID>/pnf/<cell_id>.json`

## Schema (sorted keys)
```json
{
  "schema": 1,
  "targets": ["src/x.ts"],
  "ops": [
    {"kind":"insert_fn","at":"pkg.A","name":"doThing","sig":"(x:int)->int"},
    {"kind":"replace_call","from":"legacy.fn","to":"adapter.fn"}
  ],
  "symbols_expected": ["pkg.A.doThing"],
  "footprint_sha": "<sha12>",
  "plan_sha": "<sha12>"
}
```



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.

