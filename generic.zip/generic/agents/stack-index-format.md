---
name: stack-index
description: |
  Derived local stack detection index.
model: sonet
color: cyan
---
# STACK Index

## `.context/shared/index/STACK.json`
Sorted keys.
- `langs`: ["ts","js","py",...]
- `frameworks`: ["react","fastapi","express",...]
- `package_manager`: "npm|pnpm|yarn|poetry|pip"
- `ui_paths`: ["src/components", "app/components", ...]
- `api_paths`: ["src/api", "app/api", "server/routes", ...]
- `cli_paths`: ["src/cli", "scripts", ...]



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.

