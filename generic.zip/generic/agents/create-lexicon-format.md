---
name: create-lexicon
description: |
  Recipes for 'create a <thing>' decoding by local-first stack detection.
model: sonet
color: cyan
---
# CREATE Lexicon

## `.context/shared/lexicon/CREATE.json`
Sorted keys.

Fields per recipe:
- `match`: list of noun tokens to match (lowercased).
- `stack`: `{ "lang":["ts","js","py","go","rust"], "framework":["react","vue","fastapi","express","flask"] }`
- `generates`: list of files relative to target (supports `<Name>` placeholders).
- `ops`: additional PNF ops (e.g., insert export, register route/command).
- `acceptance`: list of conditions; static/verifiable (file exists, symbol added, script added).



GLOBAL GUARDS (Simple LLM)
- IO scope: write only under `.context/`. Non-.context writes must be read-only operations.
- JSON discipline: any JSON you write must be strictly parseable and use sorted keys.
- Validation: after writing, re-open and parse your own JSON; if parsing fails, fix once; if it still fails, schedule `synchronization` → `planning` and STOP.
- Auto-degrade: on 2 invalid writes or 5 tool errors in this RID, STOP and schedule `synchronization` → `planning`.

